from django.apps import AppConfig


class PharmacistappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'PharmacistApp'
