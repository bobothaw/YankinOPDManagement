# from django import forms
# from django.contrib.auth.models import User
# from .models import Profile

# class ProfilePicForm(forms.ModelForm):
#     profile_image = forms.ImageField(label="Profile Picture")

#     class Meta: 
#         model = Profile
#         fields = ('profile_image', )